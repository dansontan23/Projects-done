////////////////////////////////////////////////////////////////
function setupGround(){
    ground = Bodies.rectangle(500, 600, 1000, 40, {isStatic: true, angle: 0});
    World.add(engine.world, [ground]);
}

////////////////////////////////////////////////////////////////
function drawGround(){
    push();
    fill(128);
    drawVertices(ground.vertices);
    pop();
}

////////////////////////////////////////////////////////////////
function setupPropeller(){
    // your code here
    propeller = Bodies.rectangle(150, 480, 200, 15, {isStatic: true, angle: angle});
    World.add(engine.world, [propeller]);
}

////////////////////////////////////////////////////////////////
//updates and draws the propeller
function drawPropeller(){
    // Save the current canvas environment
    push();
    
    // Set the angle and angular velocity of the propeller
    Body.setAngle(propeller, angle);
    propeller.angularVelocity = angleSpeed;
    angle += angleSpeed;
    
    // Save the current canvas environment
    push();
    // Set the fill color to blue
    fill(0, 0, 255);
    // Draw the vertices of the propeller
    drawVertices(propeller.vertices);
    // Restore the canvas environment
    pop();
    
    // Draw the angular velocity and angle of the propeller to the canvas
    text("Velocity: " + propeller.angularVelocity, 10, 50);
    text("Angle: " + angle, 10, 60);
    
    // Restore the canvas environment
    pop();
}


////////////////////////////////////////////////////////////////
function setupBird(){
    var bird = Bodies.circle(mouseX, mouseY, 20, {friction: 0, restitution: 0.95 });
    Matter.Body.setMass(bird, bird.mass*10);
    World.add(engine.world, [bird]);
    birds.push(bird);
}

////////////////////////////////////////////////////////////////
function drawBirds(){
    push();
    var green = color(0, 255, 0);
    var red = color(255, 0, 0);
    var tx = (20 * frameCount) * 0.01;
    var ty = (20 * frameCount) * 0.01;
    var noises = noise(tx, ty);
    var colors = lerpColor(green, red, noises);
    fill(colors);
    //your code here
    for (var i = birds.length - 1; i >= 0; i--){
        drawVertices(birds[i].vertices);
    }
    
    for (var i = birds.length - 1; i >= 0; i--){
        if (isOffScreen(birds[i])){
            removeFromWorld(birds[i]);
            birds.splice(i, 1);
        }
    }
    pop();
}

////////////////////////////////////////////////////////////////
//creates a tower of boxes
function setupTower(){
    //you code here
    boxes = Composites.stack(500, 100, 3, 6, 0, 0, createOneTowerBricks);
    
    for (var i = 0; i < boxes.bodies.length; i++){
        var g = random(100, 200);
        boxes.bodies[i].render.fillStyle = color(0, g, 0);
    }
    
    World.add(engine.world, [boxes]);    
}

function createOneTowerBricks(x, y){
    var brickStyle = {fillStyle: "green", strokeStyle: "black"};
    var body = Bodies.rectangle(x, y, 80, 80, {render: brickStyle});
    return body;
}

////////////////////////////////////////////////////////////////
//draws tower of boxes
function drawTower(){
    // Save the current canvas environment
    push();
    
    // Loop through the array of boxes
    for (var i = 0; i < boxes.bodies.length; i++){
        // Set the fill and stroke styles for the current box
        fill(boxes.bodies[i].render.fillStyle);
        stroke(boxes.bodies[i].render.strokeStyle);
        // Draw the vertices of the current box
        drawVertices(boxes.bodies[i].vertices);
    }
    
    // Loop through the array of boxes in reverse order
    for (var i = boxes.bodies.length - 1; i >= 0; i--){
        // Check if the current box is off-screen
        if (isOffScreen(boxes.bodies[i])){
            // If it is, remove it from the canvas and the array
            removeFromWorld(boxes.bodies[i]);
            boxes.bodies.splice(i, 1);
        }
        
        // If the array of boxes is empty, call the gameWin function
        if (boxes.bodies.length == 0){
            gameWin();
        }
    }
    // Restore the canvas environment
    pop();
}

////////////////////////////////////////////////////////////////
function setupSlingshot(){
    // Create a new circular body for the bird
    slingshotBird = Bodies.circle(180, 180, 20, {restitution: 0.95, friction: 0, mass: 10});
      
    // Set up the properties for the constraint
    var constraint_prop = {
        pointA: {x:200,y:200},  // Anchor point for the constraint
        bodyB: slingshotBird,   //the body the constraint is attached to
        pointB : {x:0,y:0},     //offset of the body from the anchor point
        stiffness: 0.01,        //stiffness of the constraint
        damping: 0.0001         //damping of the constraint
    };

    // Create the constraint
    slingshotConstraint = Constraint.create(constraint_prop);
    
    // Add the bird and constraint to the world
    World.add(engine.world, [slingshotBird, slingshotConstraint]);
}


////////////////////////////////////////////////////////////////
//draws slingshot bird and its constraint
function drawSlingshot(){
    // Save the current canvas environment
    push();
    
    // Draw the vertices of the bird
    drawVertices(slingshotBird.vertices);
    // Draw the constraint connecting the bird to the anchor point
    drawConstraint(slingshotConstraint);

    // Restore the canvas environment
    pop();
}


////////////////////////////////////////////////////////////////
// Additional Physics Object
function setupBlock(){
    // Create a new rectangular body for the block
    Block = Bodies.rectangle(350, 200, 15, 300, {restitution: 1.5, friction: 0, mass: 10});
      
    // Set up the properties for the constraint
    var constraint_block = {
        pointA: { x: 400, y: 0 },  //anchor point for the constraint
        bodyB: Block,              //the body the constraint is attached to
        pointB: { x: 0, y: -150 }, //offset of the body from the anchor point
        stiffness: 0.001,          //stiffness of the constraint
        damping: 0.05              //damping of the constraint
    }

    // Create the constraint
    blockConstraint = Constraint.create(constraint_block);
    
    // Add the block and constraint to the world
    World.add(engine.world, [Block, blockConstraint]);
}


////////////////////////////////////////////////////////////////
//draws moving block
function drawBlock(){
    push();
    drawVertices(Block.vertices);
    drawConstraint(blockConstraint);
    pop();
}

/////////////////////////////////////////////////////////////////
function setupMouseInteraction(){
    var mouse = Mouse.create(canvas.elt);
    var mouseParams = {mouse: mouse, constraint: {stiffness: 0.05}}
    mouseConstraint = MouseConstraint.create(engine, mouseParams);
    mouseConstraint.mouse.pixelRatio = pixelDensity();
    World.add(engine.world, mouseConstraint);
}
