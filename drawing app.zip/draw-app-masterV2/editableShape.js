function EditableShape(){

    this.icon="assets/editableShape.png";
    this.name="editableShape";

    var editButton;
    var finishButton;

    var editMode=false;
    var currentShape=[];


    this.draw=function(){ 
        updatePixels();
        if(mouseOnCanvas(canvas)&&mouseIsPressed){
            
            if(!editMode){
                //if not in edit mode, save mouse position as vertices
                console.log("hi")
                currentShape.push({x:mouseX,y:mouseY});
            }
            else{
                
                //look for nearest vertex and move it
                for(var i=0;i<currentShape.length;i++){
                    var d = dist(currentShape[i].x,currentShape[i].y,mouseX,mouseY);
                    //moving vertices starts here
                    //if distance from mouse and vertice is less than 15, attaches vertice to mouse and starts updating current location of the vertice.
                    if(d<15){
                        currentShape[i].x=mouseX;
                        currentShape[i].y=mouseY;
                    }
                }

            }
        }
        //marking the vertices so they can be edited by user
        beginShape();
        for(var i=0;i<currentShape.length;i++){
            vertex(currentShape[i].x,currentShape[i].y);
            if(editMode){
                //draw vertices as small circle
                fill("blue");
                ellipse(currentShape[i].x,currentShape[i].y,10);
                noFill();
            }
        }
        endShape();
    }
    this.unselectTool=function(){
        select("#options").html("");
        //to finish up if tool is unselected.
        this.finishButtonPressed();
    }
    this.populateOptions=function(){
        noFill();
        //when user clicks on editable shape, load pixels on canvas from memory
        loadPixels();
        //setup buttons after loading from memory
        editButton=createButton("Edit Shape");
        finishButton=createButton("Final Shape");
        editButton.mousePressed(this.editButtonPressed);
        finishButton.mousePressed(this.finishButtonPressed);
        editButton.parent("#options");
        finishButton.parent("#options");
        editButton.style("display","none");
        finishButton.style("display","none");
    }
    this.editButtonPressed=function(){
        if(editMode){
            editMode=false;
            editButton.html("Edit Shape");
        }
        else{
            editMode=true;
            editButton.html("Add Vertices");

        }

    }
    this.finishButtonPressed=function(){
        
        editButton.style("display","none");
        finishButton.style("display","none");
        
        editMode=false;
        editButton.html("Edit Shape");
        draw;
        loadPixels();
        currentShape=[];
    }
    this.mouseReleased = function(){
        if(mouseOnCanvas(canvas)&&!editMode){
            editButton.style("display","block");
            finishButton.style("display","block");
        }
    }
} 