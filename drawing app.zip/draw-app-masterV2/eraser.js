function Eraser(){
    //set an icon and a name for the object
    this.icon = "assets/eraser.png";
    this.name = "eraser";

    var sliderSize;
    var ellipseSize;
    var drawing = false;

    this.draw = function(){
        //if the mouse is pressed
        ellipseSize=sliderSize.value();
        if(mouseIsPressed){
            //if it's the start of drawing a new line
            //update the screen with the saved pixels to hide any previous
            //line between mouse pressed and released
            //draw the line
            stroke(0);
            strokeWeight(0);
            fill(255,255,255);
            ellipse(mouseX, mouseY, ellipseSize, ellipseSize);
        }


    };

    this.populateOptions=function(){        
        //creating a slider to change the size of the eraser
        //when user clicks on editable shape, load pixels on canvas from memory
        sliderSize=createSlider(5,50,20);
        sliderSize.parent("#options");


    }
    this.unselectTool=function(){
        select("#options").html("");
        stroke(1);
        strokeWeight(1);
        

        //to finish up if tool is unselected.
    }
}