function ScissorTool(){

    this.icon="assets/scissors.png"
    this.name="scissors";

    var selectMode;
    var selectedArea;

    var selectButtons;
    var selectPixels;

    this.previousMouseX= -1;
    this.previousMouseY= -1;

    var rotateAngle = 0;
    var angleSlider;

    this.draw=function(){
        if(mouseIsPressed){

            if(!mouseOnCanvas(canvas)){
                return;
            }
            if(selectMode==0){
                //if user does nothing, draw line
                if(this.previousMouseX==-1){
                    this.previousMouseX=mouseX;
                    this.previousMouseY=mouseY;

                }else{
                    stroke(0);
                    noFill();
                    line(this.previousMouseX,
                         this.previousMouseY,
                         mouseX,
                         mouseY)
                    this.previousMouseX=mouseX;
                    this.previousMouseY=mouseY;

                }
            }
            else if(selectMode==1){
                //showing a transaprent selected box that the user drag and clicks  
                updatePixels();
                noStroke();
                fill(255,0,255,100);
                rect(selectedArea.x,
                     selectedArea.y,
                     selectedArea.w,
                     selectedArea.h)
            }
        }
        else{
            if(selectMode==2){
                updatePixels();
                fill(0,0,255,100);
                push();
                translate(mouseX,mouseY);
                rotate(radians(angleSlider.value()));
                rect(-selectedArea.w/2+10,
                     -selectedArea.h/2+10,
                     selectedArea.w-20,
                     selectedArea.h-20)
                pop();

            }
            //if user has released mouse, set previous x y to -1
            this.previousMouseX= -1;
            this.previousMouseY= -1;
        }
    }
    // 0 - do nothing
    // 1 - select area cut and paste
    // 2 - paste
    this.selectButtonClicked = function(){
        if(selectMode==0){
            selectMode+=1;
            //bringing to next mode
            selectButtons.html("cut");
            //store current frame
            loadPixels();

        }
        else if(selectMode==1){
            selectMode+=1;
            selectButtons.html("end paste");
            //refresh screen
            updatePixels();
            selectedPixels=get(selectedArea.x,
                               selectedArea.y,
                               selectedArea.w,
                               selectedArea.h);
            //draw white rect over selected to show that it is cutting
            fill(255);
            noStroke();
            rect(selectedArea.x,
                 selectedArea.y,
                 selectedArea.w,
                 selectedArea.h)
        }
        else if(selectMode==2){
            selectMode=0;
            updatePixels();
            selectedArea = {x:0,y:0,w:100,h:100};
            selectButtons.html("select area")
        }
    }
    this.unselectTool=function(){
        select(".options").html("")
    }
    this.populateOptions=function(){
        selectMode = 0;
        selectedArea = {x:0,y:0,w:100,h:100};

        selectButtons=createButton("select area");
        selectButtons.parent("#options");
        selectButtons.mousePressed(this.selectButtonClicked);
        angleSlider=createSlider(0,360,0);
        angleSlider.parent("#options");
    }
    this.mousePressed=function(){
        if(!mouseOnCanvas(canvas)){
            return;
        }
        if(selectMode==1){//selection of area to cut
            selectedArea.x=mouseX;
            selectedArea.y=mouseY;
        }
        //paste image
        else if(selectMode==2){
            /*image(selectedPixels,mouseX-selectedArea.w/2,mouseY-selectedArea.h/2);*/
            push();
            translate(mouseX,mouseY);
            rotate(radians(angleSlider.value()));
            image(selectedPixels,
                  -selectedArea.w/2,
                 -selectedArea.h/2)
            pop();
            loadPixels();

        }
    }
    this.mouseDragged=function(){
        if(selectMode==1){
            var w = mouseX - selectedArea.x;
            var h = mouseY - selectedArea.y;

            selectedArea.w=w;
            selectedArea.h=h;
        }
    }
}