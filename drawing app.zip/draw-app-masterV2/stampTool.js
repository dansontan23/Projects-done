function stampTool(){
    this.icon="assets/rubber-stamp.png"
    this.name="stamptool";
    
    var star;
    var cloud;
    var imageSelector;
    var selectedImage;
    var sliderSize;
    
    this.setup=function(){
        star=loadImage("assets/star.png");
        cloud=loadImage("assets/cloud.png");
        console.log("loaded images")
    }
    //calling once for stamp tool object in sketch.js
    this.setup();
    this.draw=function(){
        console.log("stamp tool");
    }
    this.mousePressed=function(){
        //making sure mouse is always on canvas first
        if(!mouseOnCanvas(canvas)){
            return;
        }
        var imageSelected=imageSelector.value();
        if(imageSelected=="vertex"){
            this.drawVertexStamp();
        }
        else{
            var stampSize=sliderSize.value()
            var stampX= mouseX - stampSize+stampSize/2;
            var stampY= mouseY - stampSize+stampSize/2
            image(selectedImage,stampX,stampY,stampSize,stampSize);
        }
        
    }
    //creating an unselect tool
    this.unselectTool=function(){
        //unselecting stamptool
        select("#options").html("")
    }
    //creating options so that you can put different types of stamps
    this.populateOptions=function(){
        console.log("stamp tool selected")
        imageSelector=createSelect();
        imageSelector.parent("#options");
        imageSelector.option("star");
        imageSelector.option("cloud");
        imageSelector.option("vertex");
        imageSelector.changed(this.mySelectEvent);
        selectedImage=star;
        
        sliderSize=createSlider(5,50,20);
        sliderSize.parent("#options");
        
    }
    //selecting which event to handle, showing which picture
    this.mySelectEvent=function(){
        var imageSelected=imageSelector.value();
        sliderSize.style("display","block");
        if(imageSelected=="star"){
            selectedImage=star;
        } 
        else if(imageSelected=="cloud"){
            selectedImage=cloud;
        }
        //making sure that there is no slider for vertex since vertex was hard coded inside,unable to change size
        else if(imageSelected=="vertex"){
            sliderSize.style("display","none");
        }
    }
    //specifically for vertex only
    this.drawVertexStamp=function(){
        push();
        translate(mouseX,mouseY);
        beginShape();
        fill(255);
        var xOffSet = 80;
        var yOffSet = 80;
        vertex(0-xOffSet,120-yOffSet);
        vertex(50-xOffSet,90-yOffSet);
        vertex(60-xOffSet,60-yOffSet);
        vertex(40-xOffSet,20-yOffSet);
        vertex(160-xOffSet,60-yOffSet);
        vertex(110-xOffSet,80-yOffSet);
        vertex(150-xOffSet,90-yOffSet);
        vertex(90-xOffSet,100-yOffSet);
        vertex(80-xOffSet,120-yOffSet);
        endShape();
        ellipse(105-xOffSet,60-yOffSet,8,8);
        pop();    
    }
}