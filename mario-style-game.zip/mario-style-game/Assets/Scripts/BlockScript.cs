﻿using UnityEngine;
using System.Collections;

public class BlockScript : MonoBehaviour {
	
	public float min_y;
	public float max_y;
	public float move_speed;
	public bool going_down = false;

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
		if(move_speed>0) {
			if(transform.position.y < max_y && going_down==false) {
				transform.Translate (new Vector3(0, move_speed, 0));
				if(transform.position.y>= max_y) {
					going_down = true;
				}
			}

			if(transform.position.y > min_y && going_down==true) {
				transform.Translate (new Vector3(0, -move_speed, 0));
				if(transform.position.y<= min_y) {
					going_down = false;
				}
			}
		}
	}
}
