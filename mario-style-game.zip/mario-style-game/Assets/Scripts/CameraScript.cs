﻿using UnityEngine;
using System.Collections;

public class CameraScript : MonoBehaviour {
	enum sates { idle, gettingInRange, inRange }; 
	sates playerState; 
	public GameObject hero;
	public float min_x;
	public float max_x;
	
	// Use this for initialization
	void Start () {

	}

	void Update () {
		float xpos = hero.transform.position.x;
		if(xpos <= min_x) {
			xpos = min_x;
		}
		if(xpos >= max_x) {
			xpos = max_x;
		}
		transform.position = new Vector3(xpos, transform.position.y, transform.position.z);
	}
}
