﻿using UnityEngine;
using System.Collections;

public class NinjaScript : MonoBehaviour { 
	
	private Animator anim;
	public float throw_speed;
	public int shoot_chance;
	public GameObject shuriken_prefab;
	private ShurikenScript SS;

	//declaring states of the ninja
	public enum states {alive_left, alive_right, fire_left, fire_right, dead};
	public states CurrentState;
	
	void Start () {
		anim = GetComponent<Animator>();
		SS = FindObjectOfType<ShurikenScript> ();
		if(CurrentState==states.alive_left){
			transform.localScale = new Vector3 (-2, transform.localScale.y, 1);
		}
		anim.Play ("ninja_idle");
		//play the ninja's idle animation

		//if the current state is alive_left, flip the ninja to face left

	}
	
	// Update is called once per frame
	void Update () {

		//Change the if statement below to check if the current state is NOT dead
		if(CurrentState!=states.dead) {

			//Change the if statement below to check if a random number between 1 to 1000 is less than shoot_chance
			if(Random.Range(1,1000)<shoot_chance) {

				//Change the if-statement below to check if current state is alive_left
				if(CurrentState==states.alive_left) {
					anim.Play ("ninja_attack");
					CurrentState = states.fire_left;

					//Play the attack animation and set current state to fire_left
					GameObject shuriken1=Instantiate(shuriken_prefab,transform.position,transform.rotation);
					ShurikenScript SS = shuriken1.GetComponent<ShurikenScript> ();
					//Create a new shuriken prefab at the ninja's position, and set its move_speed to the ninja's throw_speed*-1
					SS.move_speed=throw_speed*-1;
					Invoke ("StopShooting", 0.5f);
					//Call the StopShooting function 0.5 seconds later

				}

				//Change the if-statement below to check if current state is alive_right
				if(CurrentState==states.alive_right) {
					anim.Play ("ninja_attack");
					CurrentState = states.fire_right;
					Instantiate(shuriken_prefab,transform.position,transform.rotation);
					Invoke ("StopShooting", 0.5f);

					//Play the attack animation and set current state to fire_right
					
					//Create a new shuriken prefab at the ninja's position, and set its move_speed to the ninja's throw_speed
					
					//Call the StopShooting function 0.5 seconds later

				} 
			}
		}
	}

	//function to make the ninja stop firing shurikens and return to the idle state
	void StopShooting() {
		anim.Play ("ninja_idle");
		//Play the ninja's idle animation
		if(CurrentState==states.fire_left){CurrentState=states.alive_left;
		}
		//If the current state is fire_left, set it to alive_left
		if (CurrentState == states.fire_right) {
			CurrentState = states.alive_right;
		}
		//If the current state is fire_right, set it to alive_right
		
	}

	//When the ninja gets kicked by the hero
	public void GotHit() {

		anim.Play ("die");
		CurrentState = states.dead;
		Invoke ("Die", 0.4f);
		//Play the ninja's die animation, and set the current state to dead, then call the Die function after 0.4 seconds

	}

	void Die() {
		Destroy (gameObject);
		//destroy the ninja

	}

}
