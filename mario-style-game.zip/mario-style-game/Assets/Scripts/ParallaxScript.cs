﻿using UnityEngine;
using System.Collections;

public class ParallaxScript : MonoBehaviour {

	private float start_camera_x;
	public float offset;

	void Start () {
		start_camera_x = Camera.main.transform.position.x;
	}

	void Update () {
		float new_x = (Camera.main.transform.position.x - start_camera_x)/offset;
		transform.position = new Vector3(new_x, transform.position.y, transform.position.z);
	}
}
