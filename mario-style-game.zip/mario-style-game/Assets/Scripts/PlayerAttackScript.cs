﻿using UnityEngine;
using System.Collections;

public class PlayerAttackScript : MonoBehaviour {
	private SamuraiScript SS;
	private NinjaScript NS;

	void Start () {
		//make player attack object invisible at the start
		gameObject.SetActive(false);

	}

	void Update () {
	
	}

	void OnTriggerEnter2D(Collider2D other) {
		PlayerScript Ps = transform.parent.GetComponent<PlayerScript> ();
		//If the other object is a samurai, call GotHit in the other object, and call PlayHit in the paren
		if (other.CompareTag ("samurai")) {
			SS = other.GetComponent<SamuraiScript> ();
			Ps.PlayHit ();
			SS.GotHit ();





		}
		if (other.CompareTag ("ninja")) {
			NS = other.GetComponent<NinjaScript> ();
			Ps.PlayHit ();
			NS.GotHit ();


		}
		//If the other object is a ninja, call GotHit in the other object, and call PlayHit in the parent
	
	}
}
