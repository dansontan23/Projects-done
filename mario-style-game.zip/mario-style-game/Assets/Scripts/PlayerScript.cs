﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class PlayerScript : MonoBehaviour {

	public float movespeed;
	public float jumppower;
	public float min_x;
	public float max_x;
	public bool grounded = false;
	private Animator anim;
	public bool attacking = false;
	public AudioClip attack_sound;
	public AudioClip thank_sound;
	public AudioClip hit_sound;
	public AudioClip jump_sound;
	public AudioClip die_sound;
	public GameObject player_attack;
	public Text life_text;
	public int life;
	public Vector3 reset_pos;
	public GameObject exitSign;


	void Start () {
		anim = GetComponent<Animator>();
		exitSign.SetActive (false);
		//Set the life text at the start

	}

	void Update () {
		life_text.text = "LIFE: " + life;
		if(Input.GetKey ("left")) {

			//Add an additional check here to check whether attacking is false
			if (attacking == false) {

				if (grounded == true) {
					anim.Play ("go");
				
				}

				//Flip the player left
				transform.localScale = new Vector3 (-2, transform.localScale.y, 1);

				if (transform.position.x > min_x) {
					transform.Translate (new Vector3 (-movespeed, 0, 0));
				}
			}
		}

		if(Input.GetKey ("right")) {

			//Add an additional check here to check whether attacking is false
			if (attacking == false) {
				if (grounded == true) {
					anim.Play ("go");
				}

			
				//Flip the player right
				transform.localScale = new Vector3 (2, transform.localScale.y, 1);

				if (transform.position.x < max_x) {
					transform.Translate (new Vector3 (movespeed, 0, 0));
				}
			}
		}

		if(Input.GetKeyUp ("left") || Input.GetKeyUp ("right")) {
			if(grounded==true) {
				anim.Play ("stop");
			}
		}
	
		if(Input.GetKeyDown ("up")) {

			//Add an additional check here to check whether attacking is false
			if (attacking == false) {
				if (grounded == true) {
					GetComponent<Rigidbody2D> ().AddForce (new Vector3 (0, jumppower, 0));
					GetComponent<AudioSource>().PlayOneShot(jump_sound	);

					//Play the jump sound

				}
			}
		}
		if(attacking==false&&Input.GetKeyDown("space")){
			attacking=true;
			anim.Play("attack");
			GetComponent<AudioSource>().PlayOneShot(attack_sound);
			player_attack.SetActive (true);
			Invoke ("StopAttack", 0.2f);


		}
		//Your code for the kick attack goes here

	}

	public void StopAttack() {
		attacking = false;
		anim.Play ("stop");
		player_attack.SetActive (false);
		//Play the stop animation, set attacking to false, and make the player attack object visible

	}

	void OnTriggerStay2D(Collider2D other)  {
		if(other.CompareTag("ground")==true) {
			grounded = true;
		}
	}

	void OnTriggerExit2D(Collider2D other)  {
		if(other.CompareTag("ground")==true) {
			grounded = false;
			Invoke ("SetJump",0.2f);
		}
	}

	void SetJump() {
		if(grounded == false) {
			anim.Play ("jump");
		}
	}

	void OnTriggerEnter2D(Collider2D other)  {

		if(other.CompareTag("ground")==true) {
			grounded = true;
			anim.Play ("stop");
		}

		//if hero touches a hostage
		if(other.CompareTag("hostage")==true) {
			Destroy (other.gameObject);
			Invoke("CheckHostages",0.2f);
			GetComponent<AudioSource>().PlayOneShot(thank_sound);


			//Play the thank you sound after rescuing the hostage

		} 

		if(other.CompareTag("exit")==true) {
			SceneManager.LoadScene("congrats");
		}
		if (other.CompareTag ("samurai") && attacking == false) {
			SamuraiScript ss = other.gameObject.GetComponent<SamuraiScript> ();
			if (ss.CurrentState != SamuraiScript.states.dead) {
				LoseLife ();
			}
		}
		if (other.CompareTag ("ninja") && attacking == false) {
			NinjaScript ns = other.gameObject.GetComponent<NinjaScript> ();
			if (ns.CurrentState != NinjaScript.states.dead) {
				LoseLife ();
			}
		}
		if (other.CompareTag ("dog") && attacking == false) {
			doggoscript ds = other.gameObject.GetComponent<doggoscript> ();
			if (ds.CurrentState != doggoscript.states.dead) {
				LoseLife ();
			}
		}
		if (other.CompareTag ("shuriken")) {
			Destroy (other.gameObject);
			LoseLife ();
		}

		//When colliding with a samurai and attacking is false, if the samurai is not dead, lose a life

		//When colliding with a ninja and attacking is false, if the samurai is not dead, lose a life

		//When colliding with a shuriken, lose a life and destroy the shuriken

	}

	void CheckHostages() {
		if (GameObject.FindGameObjectsWithTag ("hostage").Length < 1) {
			exitSign.SetActive(true);
		}
	}

	//Call this function to make the hero lose a life when he gets hit
	void LoseLife() {

		//reduce life by 1, set the life text, and play the die sound
		life-=1;
		GetComponent<AudioSource>().PlayOneShot(die_sound);
		life_text.text = "LIFE: " + life;
		if (life <= 0) {
			SceneManager.LoadScene ("game_over");
		} 
		else {
			Vector3 pos = new Vector3 (-5.22f, -0.57f, 0);
			transform.position = pos;
			
		}


		//if life is less than 1, go to game over, otherwise reset the hero's position

	}

	public void PlayHit() {
		//Play the hit sound
		GetComponent<AudioSource>().PlayOneShot(hit_sound);

	}
	public void OnBecameInvisible(){
		if (transform.position.y <= -5) {
			LoseLife ();
		}
	}

	//Add a function here that triggers if the hero leaves the screen. If the hero's Y position is less than -5, lose a life
}
