﻿using UnityEngine;
using System.Collections;

public class ShurikenScript : MonoBehaviour {

	public float move_speed;
	
	void Start () {
	
	}

	void Update () {
		//Move the shuriken by its move speed
		transform.Translate(move_speed,0,0);

	}

	//Add a function here to destroy the shuriken when it leaves the screen

	public void OnBecameInvisible(){
		Destroy (gameObject);
	}
	//Add a function here that destroys the shuriken when it collides with a block

	void OnTriggerEnter2D(Collider2D other){
		if (other.CompareTag("ground")==true) {
			Destroy (gameObject);
		}
	}
}
