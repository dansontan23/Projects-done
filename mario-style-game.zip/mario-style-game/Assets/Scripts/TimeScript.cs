﻿using UnityEngine; 
using System.Collections;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class TimeScript : MonoBehaviour {

	public Text time_text;
	public float timer;

	// Use this for initialization
	void Start () {
		time_text.text = "TIME: "+timer.ToString();
	}
	
	// Update is called once per frame
	void Update () {
		timer = timer - Time.deltaTime;
		time_text.text = "TIME: "+timer.ToString();
		if(timer <= 0) {
			SceneManager.LoadScene("game_over");
		}
	}
}
