﻿using UnityEngine;
using System.Collections;

public class doggoscript : MonoBehaviour { 

	public float min_x;
	public float max_x;
	public float move_speed;
	private Animator anim;

	//declaring states of the samurai
	public enum states {alive_left, alive_right, dead};
	public states CurrentState;

	void Start () {
		anim = GetComponent<Animator>();

		//if the current state is alive_left, flip the samurai to face left
		if(CurrentState==states.alive_left){
			transform.localScale = new Vector3 (-transform.localScale.x, transform.localScale.y, 1);
		}
		if(CurrentState==states.alive_right){
			transform.localScale = new Vector3 (transform.localScale.x, transform.localScale.y, 1);
		}
	}

	void Update () {

		//Change the if statement below to check if the current state is NOT dead
		if(CurrentState!=states.dead) {

			//Change the if statement below to check if the samurai's x position is more than min_x, and if the current state is alive_left 
			if(CurrentState==states.alive_left&&transform.position.x>min_x) {
				//Play the walk animation and move the samurai left
			
				transform.Translate (move_speed, 0, 0);
				if (transform.position.x <= min_x) {
					transform.localScale = new Vector3 (-transform.localScale.x, transform.localScale.y, 1);
					CurrentState = states.alive_right;
				}

				//If the samurai reaches min_x, flip him to face right, and set current state to alive_right

			}

			//Change the else-if statement below to check if the samurai's x position is less than max_x, and if the current state is alive_right 
			else if(CurrentState==states.alive_right&&transform.position.x<max_x) {
				//Play the walk animation and move the samurai left

				transform.Translate (-move_speed, 0, 0);
				if (transform.position.x >= max_x) {
					transform.localScale = new Vector3 (-transform.localScale.x, transform.localScale.y, 1);
					CurrentState = states.alive_left;
				}
			}
		}
	}

	//When the samurai gets kicked by the hero
	public void GotHit() {
		CurrentState = states.dead;
		Invoke ("Die", 0.4f);
		//Play the samurai's die animation, and set the current state to dead, then call the Die function after 0.4 seconds

	}

	public void Die() {
		Destroy (gameObject);
		//Destroy the samurai

	}
}
