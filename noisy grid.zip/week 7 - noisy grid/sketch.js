var stepSize = 20;

function setup() {
    createCanvas(500, 500);
}
///////////////////////////////////////////////////////////////////////
function draw() {
    background(125);

    colorGrid();
    compassGrid();
}
///////////////////////////////////////////////////////////////////////
function colorGrid(){
    // Save the current canvas environment
    push();
    
    // Set the colors white and black
    var white = color(255);
    var black = color(0);
    // Calculate a factor based on the mouse position
    var factor = map(mouseX, 0, width, 0, 1);

    // Loop through the grid and draw rectangles
    for (var x = 0; x < width; x += width/ 25){
        for (var y = 0; y < height; y += height/ 25){
            // Calculate noise values for the current position
            var tx = (x * 20 + frameCount * factor) * 0.01;
            var ty = (y * 20 + frameCount * factor) * 0.01;
             var noises = noise(tx, ty);
            // Interpolate between green and red based on the noise value
            var colors = lerpColor(white, black, noises);
            // Set the fill color and draw the rectangle
            noStroke();
            fill(colors);
            rect(x, y, stepSize, stepSize)
        }
    }
    
    // Restore the canvas environment
    pop();
}

///////////////////////////////////////////////////////////////////////
function compassGrid(){
    // Set the colors green and red
    var green = color(0, 255, 0);
    var red = color(255, 0, 0);
    // Calculate a factor based on the mouse position
    var factor = map(mouseX, 0, width, 0, 1);

    // Loop through the grid and draw rectangles
    for (var x = 0; x < width; x += width/ 25){
        for (var y = 0; y < height; y += height/ 25){
            // Save the current canvas environment
            push();
            // Translate the canvas to the center of the current rectangle
            translate(x + stepSize/2, y + stepSize/2);
            // Calculate noise values for the current position
            var tx = (x * 20 + frameCount * factor) * 0.01;
            var ty = (y * 20 + frameCount * factor) * 0.01;
            var noises = noise(tx, ty);
            // Interpolate between green and red based on the noise value
            var colors = lerpColor(green, red, noises);
            fill(colors);
            
            // Calculate the rotation angle based on the noise value
            var a = map(noises, 0, 1, 0, 720);
            // Rotate the canvas by the angle
            rotate(radians(a));
            
            // Set the rectMode to CENTER and draw the rectangle
            rectMode(CENTER);
            rect(0, 0, stepSize * noises, 5);
            // Restore the canvas environment
            pop();
        }
    }    
}

