var speed;

function setup() {
    createCanvas(900, 700);
}

function draw() {
    background(0);
    speed = frameCount;

    push();
    translate(width/2, height/2);
    //setting the sun
    celestialObjs(color(255,150,0), 200); // SUN    
        //rotating all other planets around the sun
        push();
        rotate(radians(speed));
        translate(300, 0);
        planetObj(color(0, 0, 255), 80); // EARTH
        //basic moon rotating around earth  
        push();
        rotate(radians(-speed*4));
        translate(100, 0);
        moonObj(color(255, 255, 255), 30); // MOON 1
        //add on an asteroid
        rotate(radians(speed*3));
        translate(30, 0);
        celestialObjs(color(128, 128, 128), 15); // Asteroid
        pop();
         //second moon add on
        push();
        rotate(radians(-speed*3));
        translate(65, 0);
        moonObj(color(255, 255, 255), 20); // MOON 2
        pop();
    
        pop();
    
    pop();
    

}

function celestialObjs(c, size){
    strokeWeight(5);
    rotate(radians(speed/3));
    fill(c);
    stroke(0);
    ellipse(0, 0, size, size);
    line(0, 0, size/2, 0);
}
//creating a planet object for earth
function planetObj(c, size)
{
    strokeWeight(5);
    rotate(radians(speed));
    fill(c);
    stroke(0);
    ellipse(0, 0, size, size);
    line(0, 0, size/2, 0);    
}
//creating a moon object for moon
function moonObj(c, size)
{
    strokeWeight(5);
    //rotate(radians(-speed*2));
    fill(c);
    stroke(0);
    ellipse(0, 0, size, size);
    line(0, 0, size/2, 0);    
}